import React, {useState} from 'react';
import {useSRAssetUrl} from '@sillyrealms/sdk';

type Fields = Record<string, unknown>;
const record = (v: unknown): Fields => v && typeof v === 'object' && !Array.isArray(v) ? v as Fields : {};
const text = (v: unknown) => typeof v === 'string' ? v.trim() : '';
const rows = (v: unknown): Fields[] => Array.isArray(v) ? v.map(record) : [];
const amount = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v) && v >= 0;
const numerals = ['零','一','两','三','四','五','六','七','八','九','十'];
const quantity = (v: unknown, unit: unknown) => amount(v) ? (numerals[v] ?? String(v)) + text(unit) : '数量未详';

function guestOrders(data: Fields): Fields[] {
  const current = record(data.饭馆营业).客单;
  if (Array.isArray(current)) return rows(current);
  const grouped = new Map<string, Fields[]>();
  for (const row of rows(data.待上菜单)) {
    const name = text(row.客桌);
    if (!grouped.has(name)) grouped.set(name, []);
    grouped.get(name)!.push({菜名: row.菜名, 待上: row.待上数量, 单位: row.单位});
  }
  return Array.from(grouped, ([客桌, 菜饭]) => ({客桌, 菜饭}));
}

type PageProps = {data: Fields; place: string; businessLabel: string};

function Person({name, slug, location, activity, concern}: {
  name: string; slug: string; location: string; activity: string; concern: string;
}) {
  const avatar = useSRAssetUrl('sr-asset://assets/portraits/' + slug + '.png');
  return <section className="inn-person">
    <header>{avatar && <img src={avatar} alt="" width="44" height="44"/>}<h3>{name}</h3></header>
    <dl>
      <div><dt>所在位置</dt><dd>{location || '尚未交代'}</dd></div>
      <div><dt>手头事</dt><dd>{activity || '暂无记录'}</dd></div>
      <div><dt>挂心事</dt><dd>{concern || '暂无记录'}</dd></div>
    </dl>
  </section>;
}

function Characters({data, place}: PageProps) {
  const people = [
    {name:'掌柜', slug:'keeper', oldConcern:''},
    {name:'李鱼儿', slug:'li-yuer', oldConcern:'操心的家事'},
    {name:'李鸟儿', slug:'li-niaoer', oldConcern:'自己的念想'},
  ];
  return <>{people.map(({name, slug, oldConcern}) => {
    const person = record(data[name]);
    const location = name === '掌柜' ? place : text(person.所在位置 ?? person.所在地点);
    return <Person key={slug} name={name} slug={slug} location={location}
      activity={text(person.手头事 ?? person.当前活动)} concern={text(person.挂心事 ?? person[oldConcern])}/>;
  })}</>;
}

function Hall({data, businessLabel}: PageProps) {
  const tickets = guestOrders(data);
  return <><div className="inn-revenue"><span>累计营业收入</span><strong className="inn-income">{incomeLabel(data.收支账)}</strong></div>
    <h2>饭馆营业</h2>{businessLabel && <p className="inn-business">{businessLabel}</p>}
    {tickets.length === 0 && <p className="inn-empty">暂无客单。</p>}
    {tickets.map((ticket, i) => {
      const dishes = rows(ticket.菜饭);
      const sorted = [...dishes.filter(d => d.待上 !== 0), ...dishes.filter(d => d.待上 === 0)];
      return <section className="inn-ticket" key={i}>
        <header><h3>{text(ticket.客桌)}</h3><small>{ticket.结账 === '未交代' ? '结账未详' : text(ticket.结账)}</small></header>
        <ul>{sorted.map((dish, j) => <li key={j} className={dish.待上 === 0 ? 'inn-served' : ''}>
          <span>{text(dish.菜名)}</span><span>{dish.待上 === 0 ? '已上' + (amount(dish.点量) ? ' '+quantity(dish.点量,dish.单位) : '') :
            '待上 '+quantity(dish.待上,dish.单位)}</span></li>)}</ul></section>;
    })}
    </>;
}

function Pantry({data}: {data: Fields}) {
  const stock = rows(data.食材余量);
  return <><h2>后厨存粮</h2>{stock.length ? <dl className="inn-lines">{stock.map((item,i) =>
    <div key={i}><dt>{text(item.食材)}<b>{text(item.余量)}</b></dt><dd>{text(item.备料)}</dd></div>)}</dl>
    : <p className="inn-empty">尚未记下存粮。</p>}</>;
}

function incomeLabel(value: unknown): string {
  if (amount(value)) return value.toLocaleString('zh-CN') + '文';
  // Older saves stored receipts in their original currencies.
  const receipts = record(value).流水;
  if (!Array.isArray(receipts)) return '尚未记下';
  const totals = new Map<string, number>();
  let incomplete = false;
  for (const row of rows(receipts).filter(r => r.方向 === '收入')) {
    const unit = text(row.单位);
    if (amount(row.金额) && unit) totals.set(unit, (totals.get(unit) ?? 0) + row.金额);
    else incomplete = true;
  }
  const parts = Array.from(totals, ([unit, sum]) => sum.toLocaleString('zh-CN') + unit);
  if (incomplete) parts.push('另有金额未详');
  return parts.join('、') || '0文';
}

function householdNotes(data: Fields): string[] {
  if (Array.isArray(data.家常记事)) return data.家常记事.map(text).filter(Boolean);
  const old = record(data.家常记事);
  return [
    ...rows(old.约定).map(r => [r.同谁, r.时候, r.事情, r.进展].map(text).filter(Boolean).join(' · ')),
    ...rows(old.心得 ?? data.拿手菜谱).map(r => [r.事情 ?? r.菜名, r.记法 ?? r.做法要点 ?? r.来由].map(text).filter(Boolean).join('：')),
  ].filter(Boolean);
}

function Household({data}: {data: Fields}) {
  const notes = householdNotes(data);
  return <><h2>家常记事</h2>{notes.length
    ? <ul className="inn-notes">{notes.map((note, i) => <li key={i}>{note}</li>)}</ul>
    : <p className="inn-empty">还没有记下家常事。</p>}</>;
}
const pages = {堂口:Hall, 角色:Characters, 粮柜:Pantry, 家常:Household};

export default function InnLedger({data, place, businessLabel, unavailable}: PageProps & {unavailable: string}) {
  const [page, select] = useState<keyof typeof pages>('堂口');
  const Page = pages[page];
  return <>{unavailable && <p role="status" className="inn-empty">{unavailable}</p>}
    {!!Object.keys(data).length && <><nav className="inn-pages" aria-label="翻阅账页">
      {(Object.keys(pages) as (keyof typeof pages)[]).map(label =>
        <button key={label} type="button" aria-pressed={page === label} onClick={() => select(label)}>{label}</button>)}
    </nav><section className="inn-leaf" aria-label={page}><Page data={data} place={place} businessLabel={businessLabel}/></section></>}</>;
}
