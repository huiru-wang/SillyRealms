import React, {useEffect, useRef, useState} from 'react';
import {SR, useSRStageSnapshot} from '@sillyrealms/sdk';

import InnLedger from './InnLedger';

type Fields = Record<string, unknown>;
const record = (value: unknown): Fields =>
  value && typeof value === 'object' && !Array.isArray(value) ? value as Fields : {};
const text = (value: unknown) => typeof value === 'string' ? value.trim() : '';
const rows = (value: unknown) => Array.isArray(value) ? value.map(record) : [];
const smallCounts = ['零', '一', '两', '三', '四', '五', '六', '七', '八', '九', '十'];
const count = (n: number) => smallCounts[n] ?? String(n);
const knownNumber = (v: unknown): v is number => typeof v === 'number' && Number.isSafeInteger(v) && v >= 0;

function sceneOf(place: string, closed: boolean) {
  const kitchen = /后厨|厨房|灶间|灶房/.test(place);
  const hall = /^(小饭馆|店里|店内|大堂|前堂|柜台|堂屋)|饭馆(大堂|前堂)/.test(place);
  if (kitchen || hall) return closed ? 'lamplight' : kitchen ? 'kitchen' : 'hall';
  if (/街|巷|集市|东市|西市|南市|北市|市集|摊/.test(place)) return 'street';
  return 'plain';
}

export default function InnStage() {
  const snapshot = useSRStageSnapshot();
  const data = snapshot.state.message;
  const scene = record(data.时日与场景 ?? data.当前场景), business = record(data.饭馆营业);
  const place = text(record(data.掌柜).所在位置 ?? scene.掌柜所在 ?? scene.地点), hour = text(scene.时段), phase = text(business.营业阶段);
  const closed = phase === '打烊收拾' || phase === '已歇业';
  const tone = sceneOf(place, closed);
  const inShop = ['hall', 'kitchen', 'lamplight'].includes(tone);
  const tables = business.在店客桌数;
  const tableLabel = knownNumber(tables) ? (inShop ? '' : '店内上回见到') + count(tables) + '桌客' : '';
  const businessLabel = [phase, tableLabel].filter(Boolean).join(' · ');
  const waiting = Array.isArray(business.客单)
    ? rows(business.客单).reduce((sum, ticket) => sum + rows(ticket.菜饭).filter(dish => dish.待上 !== 0).length, 0)
    : rows(data.待上菜单).length;
  const unavailable = snapshot.stateError ? '账页暂时无法读取。' : !Object.keys(data).length ? (snapshot.stateLoading ? '正在翻开账页…' : '暂无饭馆状态。') : '';
  const [narrow, setNarrow] = useState(() => window.matchMedia('(max-width: 819px)').matches);
  const sheet = useRef<HTMLDialogElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const media = window.matchMedia('(max-width: 819px)');
    const sync = () => setNarrow(media.matches);
    sync();
    media.addEventListener('change', sync);
    return () => media.removeEventListener('change', sync);
  }, []);
  const ledger = <InnLedger data={data} place={place} businessLabel={businessLabel} unavailable={unavailable}/>;
  const location = <span className="inn-location"><small>{[knownNumber(scene.故事日) ? '第' + scene.故事日 + '日' : '', hour].filter(Boolean).join(' · ')}</small><strong>{place || '小饭馆'}</strong></span>;

  return <div className="inn-stage" data-tone={tone}>
    <style>{styles}</style>
    <header className="inn-head">{narrow
      ? <button className="inn-trigger" ref={trigger} aria-haspopup="dialog" aria-controls="inn-sheet"
          onClick={() => sheet.current?.showModal()}>{location}<span>{waiting ? '待上' + count(waiting) + '样' : '柜台账页'}　›</span></button>
      : location}
    </header>
    <div className="inn-body"><main className="inn-reading"><SR.WorldStory showState={false}/></main>
      {!narrow && <aside className="inn-paper" aria-label="柜台账页">{ledger}</aside>}
    </div>
    {narrow && <dialog id="inn-sheet" ref={sheet} className="inn-sheet" aria-labelledby="inn-sheet-title"
      onClose={() => trigger.current?.focus({preventScroll: true})}
      onClick={e => {if (e.target === e.currentTarget) {
        const bounds = e.currentTarget.getBoundingClientRect();
        if (e.clientY < bounds.top || e.clientY > bounds.bottom || e.clientX < bounds.left || e.clientX > bounds.right) sheet.current?.close();
      }}}>
      <div className="inn-sheet-head"><h2 id="inn-sheet-title">柜台账页</h2>
        <button onClick={() => sheet.current?.close()} autoFocus>收起</button></div>
      {ledger}
    </dialog>}
  </div>;
}

//正文沿用宿主阅读主题。柜台只在纸边、点菜单和场景页眉取色。
const styles = `
.inn-stage {
  --ink:var(--sr-story-text,#342d26); --surface:var(--sr-story-surface,#fffdfa);
  --grain:#8b6648; --seal:#933e2e; --line:color-mix(in srgb,var(--grain) 27%,var(--surface));
  --paper:color-mix(in srgb,var(--grain) 7%,var(--surface));
  --muted:color-mix(in srgb,var(--ink) 77%,var(--paper));
  --serif:"Songti SC","STSong","Noto Serif CJK SC",serif;
  height:100%; min-height:0; display:flex; flex-direction:column; overflow:hidden;
  color:var(--ink); background:var(--surface); font:400 15px/1.55 system-ui,sans-serif;
}
.inn-stage[data-tone="kitchen"] {--grain:#98604b; --seal:#47613c}
.inn-stage[data-tone="street"] {--grain:#586e78; --seal:#475e70}
.inn-stage[data-tone="lamplight"] {--grain:#a26c36; --seal:#83512b}
.inn-stage[data-tone="plain"] {--grain:#817967; --seal:#665747}
:root[data-theme="dark"] .inn-stage {--ink:var(--sr-story-text,#ede6db); --surface:var(--sr-story-surface,#272520); --seal:#e8b6a3}
:root[data-theme="dark"] .inn-stage[data-tone="kitchen"] {--seal:#b6cba4}
:root[data-theme="dark"] .inn-stage[data-tone="street"] {--seal:#b7cad5}
:root[data-theme="dark"] .inn-stage[data-tone="lamplight"] {--seal:#efd0a5}
.inn-head {flex:none; border-top:3px solid var(--grain); border-bottom:1px solid var(--line); background:var(--paper); padding:10px 22px; display:flex; align-items:center; justify-content:space-between; gap:12px}
.inn-location {display:flex; align-items:baseline; gap:12px; min-width:0; overflow-wrap:anywhere}
.inn-location small,.inn-business,.inn-empty {color:var(--muted); font-size:13px}
.inn-location strong,.inn-paper h2,.inn-sheet h2 {font-family:var(--serif); font-weight:600}
.inn-location strong {font-size:22px; line-height:1.3}
.inn-business {margin:4px 0 12px}
.inn-body {display:flex; flex:1; min-height:0}
.inn-reading {min-width:0; min-height:0; flex:1}
.inn-stage .sr-story-content {font-family:var(--serif)}
.inn-paper,.inn-sheet {background:var(--paper); color:var(--ink); overflow-wrap:anywhere; overscroll-behavior:contain}
.inn-paper {width:clamp(250px,29%,350px); flex:none; overflow:auto; border-left:1px solid var(--line); padding:24px 20px max(24px,var(--sr-story-bottom-inset,0px))}
.inn-paper h2,.inn-sheet h2 {font-size:20px; margin:0; line-height:1.4}
.inn-pages {display:grid; grid-template-columns:repeat(4,1fr); border-bottom:1px solid var(--line); margin-bottom:20px}
.inn-pages button {min-height:44px; background:transparent; color:var(--muted); border:0; border-bottom:2px solid transparent; font:inherit; cursor:pointer}
.inn-pages button[aria-pressed="true"] {border-bottom-color:var(--seal); color:var(--ink); font-weight:600}
.inn-ticket header,.inn-lines dt {display:flex; align-items:baseline; justify-content:space-between; gap:12px}
.inn-ticket header small,.inn-served,.inn-lines dd {font-size:13px; color:var(--muted)}

.inn-lines {margin:8px 0 16px}
.inn-lines>div {padding:10px 0; border-bottom:1px solid var(--line)}
.inn-lines dt {font-weight:600}
.inn-lines b {font-size:14px; color:var(--seal); text-align:end; font-weight:500}
.inn-lines dd {margin:4px 0 0}
.inn-revenue {display:flex; align-items:baseline; justify-content:space-between; gap:12px; padding-bottom:12px; margin-bottom:16px; border-bottom:1px solid var(--line)}
.inn-income { color:var(--seal); font:600 28px/1.4 var(--serif); font-variant-numeric:tabular-nums}
.inn-notes {list-style:disc; padding-inline-start:1.3em; margin:12px 0}
.inn-notes li {padding:7px 0; line-height:1.65}
.inn-notes li::marker {color:var(--grain)}
.inn-location small {flex:none}
.inn-ticket {margin:14px 0 0; background:var(--surface); border-inline-start:3px solid var(--grain); padding:12px 15px}
.inn-ticket h3 {font:600 13px/1.5 system-ui,sans-serif; color:var(--seal); margin:0 0 5px}
.inn-ticket ul {list-style:none; padding:0; margin:0}
.inn-ticket li {display:flex; justify-content:space-between; align-items:baseline; gap:14px; padding:5px 0; border-bottom:1px dotted var(--line)}
.inn-ticket li:last-child {border:0}
.inn-ticket li span:last-child {color:var(--muted); flex:none}
.inn-person {border-bottom:1px solid var(--line); padding:12px 0}
.inn-person:first-child {padding-top:0}
.inn-person header {display:flex; align-items:center; gap:12px}
.inn-person img {width:44px; height:44px; object-fit:cover; border-radius:8px; flex:none}
.inn-person h3 {font:600 18px/1.4 var(--serif); margin:0}
.inn-person dl {margin:10px 0 0}
.inn-person dl>div {display:grid; grid-template-columns:4.2em 1fr; gap:8px; margin:3px 0}
.inn-person dt {color:var(--muted); font-size:13px}
.inn-person dd {margin:0}
.inn-empty {margin:4px 0 10px}
.inn-stage button:focus-visible {outline:2px solid var(--sr-story-focus,var(--seal)); outline-offset:2px}
.inn-trigger,.inn-sheet-head button {font:inherit; color:inherit; border:0; background:transparent; cursor:pointer}
.inn-trigger {display:flex; align-items:center; justify-content:space-between; width:100%; gap:8px; padding:8px 14px; min-height:46px; text-align:left}
.inn-trigger>span:last-child {white-space:nowrap; font-size:13px; color:var(--muted)}
.inn-sheet {position:fixed; inset:auto 0 var(--sr-story-bottom-inset,0px); margin:0; width:100%; max-width:100%; max-height:calc(93% - var(--sr-story-bottom-inset,0px)); overflow:auto; padding:16px 20px max(18px,env(safe-area-inset-bottom)); border:0; border-top:3px solid var(--grain); border-radius:14px 14px 0 0}
.inn-sheet::backdrop {background:rgb(24 20 16 / .42)}
.inn-sheet-head {display:flex; align-items:center; justify-content:space-between; gap:12px}
.inn-sheet-head button {min-height:44px; padding:0 10px}
@media(max-width:819px){.inn-head {padding:0}.inn-location {gap:8px}.inn-location strong {font-size:18px}}
`;
