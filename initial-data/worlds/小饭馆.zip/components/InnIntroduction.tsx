import React from 'react';
import {useSRAssetUrl} from '@sillyrealms/sdk';

const family = [
  {id: 'keeper', name: '掌柜的', work: '掌勺'},
  {id: 'li-yuer', name: '李鱼儿', work: '管账'},
  {id: 'li-niaoer', name: '李鸟儿', work: '跑堂'},
];

function Portrait({person}: {person: typeof family[number]}) {
  const image = useSRAssetUrl('sr-asset://assets/portraits/' + person.id + '.png');
  return <li><img src={image ?? undefined} width="44" height="44" alt=""/>
    <span><strong>{person.name}</strong><small>{person.work}</small></span></li>;
}

export default function InnIntroduction() {
  const cover = useSRAssetUrl('sr-asset://assets/cover.png');
  return <article className="inn-intro" aria-labelledby="inn-intro-title">
    <style>{styles}</style>
    <img className="inn-cover" src={cover ?? undefined} width="512" height="768"
      alt="原卡封面，青衣红围裙的女子站在木案上，伸手擦拭高处的木窗。"/>
    <header><p>大离 · 京城</p><h1 id="inn-intro-title">小饭馆</h1></header>
    <div className="inn-prose">
      <p>五年前，你辞了天下第一的名头，到京城巷子里开了家小饭馆。刚开张那会儿，李家姐妹正为安葬父亲发愁。你接她们进了门，从此家里吃饭，桌上就摆三副碗筷。</p>
      <p>姐姐鱼儿管账。两条草鱼比前天贵了三文，她拿朱笔一圈，等你买菜回来问个明白。妹妹鸟儿跑堂，隔着门帘就能听见她招呼客人。新菜端出来，她总要先尝一口；盐搁重了，她也真肯说。</p>
      <p>你管灶上的事。对街包子铺刚揭蒸笼，巷口的菜担子吱呀一声过去。粗瓷碗里的茶还烫着，倒够你坐一会儿，想想今儿给她们做什么吃。</p>
    </div>
    <ul className="inn-family" aria-label="小饭馆里的一家人">{family.map(person => <Portrait key={person.id} person={person}/>)}</ul>
  </article>;
}

const styles = `
.inn-intro {
  --paper:color-mix(in srgb,var(--surface,#fffdfa) 94%,#b97b49);
  --ink:var(--text,#332a23); --faded:color-mix(in srgb,var(--ink) 78%,var(--paper));
  --rule:color-mix(in srgb,var(--ink) 22%,var(--paper));
  --serif:"Songti SC","STSong","Noto Serif CJK SC",serif;
  display:grid; grid-template-columns:minmax(140px,.70fr) minmax(0,1.3fr);
  grid-template-areas:"cover title" "cover prose" "cover family";
  align-content:center; gap:16px clamp(18px,4vw,46px);
  max-width:980px; margin:0 auto; padding:clamp(16px,3vw,32px);
  color:var(--ink); background:var(--paper); border-top:3px solid #9b5136;
}
.inn-intro .inn-cover {grid-area:cover; align-self:center; justify-self:center; width:100%; height:auto; max-width:310px; display:block}
.inn-intro header {grid-area:title; align-self:end}
.inn-intro header p,.inn-intro header h1,.inn-intro .inn-prose p {margin:0}
.inn-intro header p {color:var(--faded); font-size:13px; letter-spacing:.15em}
.inn-intro header h1 {font:600 clamp(32px,5vw,52px)/1.3 var(--serif); letter-spacing:.07em; margin-top:2px}
.inn-intro .inn-prose {grid-area:prose; font:400 16px/1.85 var(--serif)}
.inn-intro .inn-prose p+p {margin-top:.8em}
.inn-intro .inn-family {grid-area:family; list-style:none; display:flex; flex-wrap:wrap; gap:12px 22px;
  padding:14px 0 0; margin:0; border-top:1px solid var(--rule); align-self:start}
.inn-intro .inn-family li {display:flex; align-items:center; gap:8px}
.inn-intro .inn-family img {width:44px; height:44px; border-radius:50%; object-fit:cover}
.inn-intro .inn-family span {display:grid; line-height:1.5}
.inn-intro .inn-family strong {font-weight:600; font-size:14px}
.inn-intro .inn-family small {color:var(--faded); font-size:12px}
@media(max-width:600px) {
  .inn-intro {grid-template-columns:minmax(80px,26%) 1fr; grid-template-areas:"cover title" "prose prose" "family family"; gap:16px; padding:16px}
  .inn-intro header {align-self:center}
  .inn-intro .inn-family {display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:8px}
  .inn-intro .inn-family li {flex-direction:column; align-items:flex-start; gap:5px}
}
`;
